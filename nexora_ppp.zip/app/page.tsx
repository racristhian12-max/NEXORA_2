"use client"

import { useEffect, useRef, useState } from "react"

type PageId = "inicio" | "nosotros" | "herramientas" | "servicios" | "planes"

const NAV_LINKS: { id: PageId; label: string }[] = [
  { id: "inicio", label: "Inicio" },
  { id: "nosotros", label: "Nosotros" },
  { id: "herramientas", label: "Herramientas IA" },
  { id: "servicios", label: "Servicios" },
  { id: "planes", label: "Planes" },
]

/* ========== Logo ========== */
function Logo({ onClick }: { onClick?: () => void }) {
  return (
    <button
      onClick={onClick}
      className="flex items-center gap-2.5"
      aria-label="NEXORA inicio"
    >
      <span
        className="flex h-[38px] w-[38px] items-center justify-center rounded-[10px] font-sans text-white"
        style={{
          background: "linear-gradient(135deg, #2563a8, #4a9eda)",
          boxShadow: "0 6px 18px rgba(37,99,168,0.35)",
          fontWeight: 700,
        }}
      >
        N
      </span>
      <span
        className="font-sans font-semibold"
        style={{
          color: "var(--blue-deep)",
          letterSpacing: "1.5px",
          fontSize: "1.05rem",
        }}
      >
        NEXORA
      </span>
    </button>
  )
}

/* ========== Navbar ========== */
function Navbar({
  current,
  onNavigate,
}: {
  current: PageId
  onNavigate: (page: PageId) => void
}) {
  const [scrolled, setScrolled] = useState(false)
  const [open, setOpen] = useState(false)

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12)
    window.addEventListener("scroll", onScroll)
    return () => window.removeEventListener("scroll", onScroll)
  }, [])

  return (
    <header className={`navbar ${scrolled ? "scrolled" : ""}`}>
      <div className="mx-auto flex h-full max-w-7xl items-center justify-between px-5 md:px-8">
        <Logo onClick={() => onNavigate("inicio")} />

        {/* Desktop nav */}
        <nav className="hidden items-center gap-1 md:flex">
          {NAV_LINKS.map((l) => (
            <button
              key={l.id}
              onClick={() => onNavigate(l.id)}
              className={`nav-link ${current === l.id ? "active" : ""}`}
            >
              {l.label}
            </button>
          ))}
          <button
            onClick={() => onNavigate("planes")}
            className="btn-primary ml-3"
            style={{ padding: "0.6rem 1.3rem", fontSize: "0.9rem" }}
          >
            Comenzar →
          </button>
        </nav>

        {/* Mobile toggle */}
        <button
          className="md:hidden p-2 rounded-lg"
          aria-label="Abrir menú"
          onClick={() => setOpen((v) => !v)}
          style={{ color: "var(--blue-deep)" }}
        >
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
            <path
              d="M3 6h18M3 12h18M3 18h18"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
            />
          </svg>
        </button>
      </div>

      {/* Mobile menu */}
      {open && (
        <div
          className="md:hidden absolute left-0 right-0 top-[70px] border-t flex flex-col gap-1 p-4"
          style={{
            background: "rgba(255,255,255,0.95)",
            backdropFilter: "blur(20px)",
            borderColor: "rgba(168,212,240,0.4)",
          }}
        >
          {NAV_LINKS.map((l) => (
            <button
              key={l.id}
              onClick={() => {
                onNavigate(l.id)
                setOpen(false)
              }}
              className={`nav-link text-left ${current === l.id ? "active" : ""}`}
            >
              {l.label}
            </button>
          ))}
          <button
            onClick={() => {
              onNavigate("planes")
              setOpen(false)
            }}
            className="btn-primary mt-2"
            style={{ padding: "0.7rem 1.3rem" }}
          >
            Comenzar →
          </button>
        </div>
      )}
    </header>
  )
}

/* ========== Reveal hook ========== */
function useReveal() {
  useEffect(() => {
    const els = document.querySelectorAll(".reveal")
    const io = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) => {
          if (e.isIntersecting) {
            e.target.classList.add("visible")
            io.unobserve(e.target)
          }
        })
      },
      { threshold: 0.12 }
    )
    els.forEach((el) => io.observe(el))
    return () => io.disconnect()
  }, [])
}

/* ========== Tool icons (SVG) ========== */
function StoreIcon() {
  return (
    <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
      <path
        d="M3 9l1.5-5h15L21 9M3 9v11h18V9M3 9h18M9 13h6"
        stroke="#10b981"
        strokeWidth="1.8"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  )
}
function MicIcon() {
  return (
    <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
      <rect x="9" y="3" width="6" height="12" rx="3" stroke="#7c3aed" strokeWidth="1.8" />
      <path d="M5 11a7 7 0 0014 0M12 18v3" stroke="#7c3aed" strokeWidth="1.8" strokeLinecap="round" />
    </svg>
  )
}
function ClipIcon() {
  return (
    <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
      <rect x="3" y="6" width="14" height="12" rx="2" stroke="#0f172a" strokeWidth="1.8" />
      <path d="M17 10l4-2v8l-4-2z" stroke="#0f172a" strokeWidth="1.8" strokeLinejoin="round" />
    </svg>
  )
}
function CheckIcon() {
  return (
    <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
      <path
        d="M4 12l5 5L20 6"
        stroke="#ec4899"
        strokeWidth="2.2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  )
}

/* ========== Tool mini ========== */
function ToolMini({
  icon,
  name,
  sub,
  iconBg,
}: {
  icon: React.ReactNode
  name: string
  sub: string
  iconBg: string
}) {
  return (
    <div
      className="flex items-center gap-3 rounded-[12px] p-3"
      style={{
        background: "rgba(255,255,255,0.7)",
        border: "1px solid rgba(168,212,240,0.4)",
      }}
    >
      <span
        className="flex h-10 w-10 shrink-0 items-center justify-center rounded-[10px]"
        style={{ background: iconBg }}
      >
        {icon}
      </span>
      <div className="min-w-0">
        <div className="font-sans text-[0.92rem] font-semibold" style={{ color: "var(--blue-deep)" }}>
          {name}
        </div>
        <div className="text-[0.78rem]" style={{ color: "var(--text-soft)" }}>
          {sub}
        </div>
      </div>
    </div>
  )
}

function ProgressRow({ label, value }: { label: string; value: number }) {
  return (
    <div>
      <div className="mb-1.5 flex justify-between text-[0.85rem]">
        <span style={{ color: "var(--text-mid)", fontWeight: 500 }}>{label}</span>
        <span style={{ color: "var(--blue-mid)", fontWeight: 600 }}>{value}%</span>
      </div>
      <div className="progress-track">
        <div className="progress-fill" style={{ width: `${value}%`, animationDuration: "1.6s" }} />
      </div>
    </div>
  )
}

/* ========== HERO ========== */
function HeroSection({ onNavigate }: { onNavigate: (p: PageId) => void }) {
  return (
    <div className="relative pt-[110px] pb-20">
      <div className="mx-auto grid max-w-7xl items-center gap-12 px-5 md:px-8 lg:grid-cols-[1.1fr_1fr]">
        <div>
          <div
            className="reveal inline-flex items-center gap-2 rounded-full px-4 py-2"
            style={{
              background: "rgba(255,255,255,0.7)",
              border: "1px solid rgba(168,212,240,0.5)",
              backdropFilter: "blur(12px)",
            }}
          >
            <span className="pulse-dot" />
            <span className="text-[0.85rem] font-medium" style={{ color: "var(--text-mid)" }}>
              Plataforma integral de crecimiento digital
            </span>
          </div>

          <h1
            className="reveal reveal-d1 mt-6 font-sans font-bold leading-[1.05] text-balance"
            style={{
              fontSize: "clamp(2.6rem, 6vw, 4.4rem)",
              color: "var(--blue-deep)",
            }}
          >
            Impulsa tu negocio con <span className="gradient-text">inteligencia artificial</span>
          </h1>

          <p
            className="reveal reveal-d2 mt-6 max-w-xl text-pretty leading-relaxed"
            style={{ color: "var(--text-mid)", fontSize: "1.05rem" }}
          >
            NEXORA combina comercio electrónico, marketing estratégico y automatización empresarial para
            que los emprendedores crezcan sin límites en el entorno digital.
          </p>

          <div className="reveal reveal-d3 mt-8 flex flex-wrap gap-3">
            <button onClick={() => onNavigate("planes")} className="btn-primary">
              Ver planes →
            </button>
            <button onClick={() => onNavigate("nosotros")} className="btn-secondary">
              Conocer más
            </button>
          </div>

          <div className="reveal reveal-d4 mt-12 grid max-w-md grid-cols-3 gap-6">
            {[
              { n: "3", l: "Líneas estratégicas" },
              { n: "4", l: "IAs integradas" },
              { n: "100%", l: "Digital & remoto" },
            ].map((s) => (
              <div key={s.l}>
                <div
                  className="font-sans font-bold"
                  style={{ color: "var(--blue-deep)", fontSize: "2.2rem", lineHeight: 1 }}
                >
                  {s.n}
                </div>
                <div className="mt-1 text-[0.8rem]" style={{ color: "var(--text-soft)" }}>
                  {s.l}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Floating card */}
        <div className="reveal reveal-d2 glass-card p-6 md:p-7">
          <div className="grid grid-cols-2 gap-3">
            <ToolMini icon={<StoreIcon />} name="Build Your Store" sub="E-commerce IA" iconBg="#d1fae5" />
            <ToolMini icon={<MicIcon />} name="Autopod" sub="Podcasts IA" iconBg="#ede9fe" />
            <ToolMini icon={<ClipIcon />} name="Opus Clip" sub="Video clips IA" iconBg="#f1f5f9" />
            <ToolMini icon={<CheckIcon />} name="ClickUp" sub="Gestión IA" iconBg="#fce7f3" />
          </div>
          <div className="mt-6 space-y-4">
            <ProgressRow label="Comercio Digital" value={92} />
            <ProgressRow label="Marketing IA" value={87} />
            <ProgressRow label="Automatización" value={95} />
          </div>
        </div>
      </div>
    </div>
  )
}

/* ========== NOSOTROS ========== */
function NosotrosSection({ onNavigate }: { onNavigate: (p: PageId) => void }) {
  const cards = [
    {
      icon: "🎯",
      title: "Misión",
      text: "Brindar soluciones integrales de crecimiento digital a emprendedores y pequeñas empresas mediante comercio electrónico, marketing estratégico y automatización empresarial, optimizando su tiempo, recursos y posicionamiento en el entorno digital.",
    },
    {
      icon: "🚀",
      title: "Visión",
      text: "Consolidarnos como empresa líder en soluciones digitales estratégicas para emprendedores en Latinoamérica, destacando por innovación tecnológica, eficiencia operativa y enfoque personalizado, con un modelo escalable y sostenible a largo plazo.",
    },
    {
      icon: "⚡",
      title: "Valor diferencial",
      text: "Un ecosistema integral que elimina la necesidad de múltiples proveedores, ofreciendo una solución centralizada, accesible y orientada a resultados que convierte procesos complejos en soluciones simples.",
    },
  ]

  return (
    <div className="relative pt-[110px] pb-20">
      <div className="mx-auto grid max-w-7xl gap-12 px-5 md:px-8 lg:grid-cols-2 lg:gap-16">
        <div>
          <span className="section-tag reveal">Quiénes somos</span>
          <h2
            className="reveal reveal-d1 mt-4 font-sans font-bold leading-[1.1] text-balance"
            style={{ fontSize: "clamp(2rem, 4.5vw, 3.2rem)", color: "var(--blue-deep)" }}
          >
            La empresa digital que tu negocio necesita
          </h2>
          <p
            className="reveal reveal-d2 mt-5 leading-relaxed"
            style={{ color: "var(--text-mid)", fontSize: "1.02rem" }}
          >
            Somos una agencia digital especializada en emprendedores y PYMES. Nuestra propuesta integra
            tecnología inteligente con acompañamiento personalizado para transformar procesos complejos
            en soluciones simples y eficientes.
          </p>
          <p
            className="reveal reveal-d3 mt-4 leading-relaxed text-[0.95rem]"
            style={{ color: "var(--text-soft)" }}
          >
            En el entorno digital, los pequeños emprendedores enfrentan barreras estructurales:
            desconocimiento tecnológico, limitaciones de tiempo y escasa estrategia de marketing
            digital. Mientras las grandes empresas invierten en automatización e inteligencia de datos,
            los pequeños negocios operan con procesos manuales. NEXORA surge como la solución.
          </p>
          <div className="reveal reveal-d4 mt-8">
            <button onClick={() => onNavigate("planes")} className="btn-primary">
              Ver nuestros planes →
            </button>
          </div>
        </div>

        <div className="flex flex-col gap-5">
          {cards.map((c, i) => (
            <div key={c.title} className={`glass-card p-6 reveal reveal-d${i + 1}`}>
              <div className="flex items-center gap-3">
                <span
                  className="flex h-12 w-12 items-center justify-center rounded-[12px] text-2xl"
                  style={{ background: "var(--blue-light)" }}
                >
                  {c.icon}
                </span>
                <h3 className="font-sans text-[1.2rem] font-semibold" style={{ color: "var(--blue-deep)" }}>
                  {c.title}
                </h3>
              </div>
              <p className="mt-3 leading-relaxed text-[0.95rem]" style={{ color: "var(--text-mid)" }}>
                {c.text}
              </p>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}

/* ========== HERRAMIENTAS ========== */
function HerramientasSection() {
  const tools = [
    {
      icon: <StoreIcon />,
      iconBg: "#d1fae5",
      name: "Build Your Store",
      desc: "Plataforma de inteligencia artificial para crear y optimizar tiendas en línea de forma rápida y funcional. Ideal para emprendedores que quieren digitalizar sus ventas sin conocimientos técnicos previos. Genera descripciones de productos, configura métodos de pago y aplica estrategias de conversión automáticamente.",
      tags: ["E-commerce", "Tiendas online", "Conversión", "Productos IA"],
    },
    {
      icon: <MicIcon />,
      iconBg: "#ede9fe",
      name: "Autopod",
      desc: "Herramienta de edición de podcast impulsada por IA que automatiza cortes, elimina silencios y genera episodios listos para publicar. Perfecta para creadores de contenido y marcas personales que desean profesionalizar su audio sin invertir horas de edición manual.",
      tags: ["Podcasts", "Edición IA", "Contenido audio", "Automatización"],
    },
    {
      icon: <ClipIcon />,
      iconBg: "#f1f5f9",
      name: "Opus Clip",
      desc: "IA que transforma videos largos en micro-contenidos virales para redes sociales. Detecta automáticamente los momentos más impactantes y los convierte en clips optimizados para TikTok, Instagram Reels y YouTube Shorts, potenciando el engagement de tu marca.",
      tags: ["Video IA", "Redes sociales", "Clips virales", "Engagement"],
    },
    {
      icon: <CheckIcon />,
      iconBg: "#fce7f3",
      name: "ClickUp",
      desc: "Plataforma todo-en-uno de gestión de proyectos potenciada con IA. Permite automatizar flujos de trabajo, coordinar equipos y hacer seguimiento de tareas para maximizar la productividad operativa. Incluye plantillas personalizadas y reportes inteligentes de desempeño.",
      tags: ["Gestión", "Automatización", "Productividad", "Reportes IA"],
    },
  ]

  return (
    <div className="relative pt-[110px] pb-20">
      <div className="mx-auto max-w-7xl px-5 md:px-8">
        <div className="mx-auto max-w-3xl text-center">
          <span className="section-tag reveal">Inteligencias Artificiales</span>
          <h2
            className="reveal reveal-d1 mt-4 font-sans font-bold leading-[1.1] text-balance"
            style={{ fontSize: "clamp(2rem, 4.5vw, 3rem)", color: "var(--blue-deep)" }}
          >
            Tecnología IA al servicio de tu negocio
          </h2>
          <p
            className="reveal reveal-d2 mt-5 leading-relaxed text-pretty"
            style={{ color: "var(--text-mid)" }}
          >
            Incorporamos las herramientas de inteligencia artificial más potentes del mercado para
            automatizar, optimizar y escalar cada aspecto de tu empresa digital.
          </p>
        </div>

        <div className="mt-12 grid gap-6 md:grid-cols-2">
          {tools.map((t, i) => (
            <div key={t.name} className={`glass-card p-7 reveal reveal-d${(i % 4) + 1}`}>
              <span
                className="flex h-14 w-14 items-center justify-center rounded-[14px]"
                style={{ background: t.iconBg }}
              >
                {t.icon}
              </span>
              <h3
                className="mt-5 font-sans font-semibold"
                style={{ color: "var(--blue-deep)", fontSize: "1.05rem" }}
              >
                {t.name}
              </h3>
              <p className="mt-2 leading-relaxed text-[0.92rem]" style={{ color: "var(--text-mid)" }}>
                {t.desc}
              </p>
              <div className="mt-4 flex flex-wrap gap-2">
                {t.tags.map((tag) => (
                  <span key={tag} className="tag-pill">
                    {tag}
                  </span>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}

/* ========== SERVICIOS ========== */
function ServiciosSection({ onNavigate }: { onNavigate: (p: PageId) => void }) {
  const lines = [
    {
      n: "01",
      title: "Comercio Digital",
      intro:
        "Digitaliza tu negocio con una tienda en línea funcional, optimizada y adaptada a tu mercado objetivo. Atendemos emprendedores, PYMES y negocios locales que buscan presencia digital.",
      items: [
        "Diseño estructural de tienda",
        "Optimización de descripciones de producto",
        "Configuración de métodos de pago",
        "Estrategia básica de conversión",
        "Catálogos digitales y sistemas de pedidos",
      ],
    },
    {
      n: "02",
      title: "Marketing Inteligente",
      intro:
        "Convierte tu contenido largo en micro-contenidos estratégicos de alto impacto para redes sociales. Potencia tu engagement y posicionamiento digital con IA.",
      items: [
        "Análisis de contenido existente",
        "Segmentación de momentos clave",
        "Edición optimizada para engagement",
        "Entrega de contenido listo para publicar",
        "Estrategias de crecimiento en redes sociales",
      ],
    },
    {
      n: "03",
      title: "Automatización Empresarial",
      intro:
        "Optimiza los procesos internos de tu empresa mediante herramientas inteligentes y flujos automatizados que eliminan tareas repetitivas y mejoran la eficiencia.",
      items: [
        "Diseño de flujos de trabajo",
        "Automatización de tareas repetitivas",
        "Implementación de sistemas de seguimiento",
        "Venta de plantillas de productividad",
        "Capacitación en herramientas digitales",
      ],
    },
  ]

  return (
    <div className="relative pt-[110px] pb-20">
      <div className="mx-auto max-w-7xl px-5 md:px-8">
        <div className="mx-auto max-w-3xl text-center">
          <span className="section-tag reveal">Nuestros servicios</span>
          <h2
            className="reveal reveal-d1 mt-4 font-sans font-bold leading-[1.1] text-balance"
            style={{ fontSize: "clamp(2rem, 4.5vw, 3rem)", color: "var(--blue-deep)" }}
          >
            Tres líneas estratégicas integradas
          </h2>
          <p
            className="reveal reveal-d2 mt-5 leading-relaxed text-pretty"
            style={{ color: "var(--text-mid)" }}
          >
            Cada línea está diseñada para atacar un problema específico de los emprendedores,
            funcionando de forma independiente o en conjunto para maximizar resultados y competitividad
            digital.
          </p>
        </div>

        <div className="mt-12 grid gap-6 md:grid-cols-3">
          {lines.map((l, i) => (
            <div key={l.n} className={`glass-card p-7 reveal reveal-d${i + 1} flex flex-col`}>
              <span
                className="font-sans font-bold"
                style={{
                  fontSize: "2.4rem",
                  background: "linear-gradient(135deg, #2563a8, #4a9eda)",
                  WebkitBackgroundClip: "text",
                  backgroundClip: "text",
                  color: "transparent",
                  lineHeight: 1,
                }}
              >
                {l.n}
              </span>
              <h3
                className="mt-3 font-sans font-semibold"
                style={{ color: "var(--blue-deep)", fontSize: "1.25rem" }}
              >
                {l.title}
              </h3>
              <p className="mt-3 text-[0.92rem] leading-relaxed" style={{ color: "var(--text-mid)" }}>
                {l.intro}
              </p>
              <ul className="mt-5 space-y-2.5">
                {l.items.map((it) => (
                  <li key={it} className="flex items-start gap-2 text-[0.9rem]" style={{ color: "var(--text-mid)" }}>
                    <svg
                      width="18"
                      height="18"
                      viewBox="0 0 24 24"
                      fill="none"
                      className="mt-0.5 shrink-0"
                    >
                      <circle cx="12" cy="12" r="10" fill="var(--blue-light)" />
                      <path
                        d="M8 12l3 3 5-6"
                        stroke="var(--blue-mid)"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      />
                    </svg>
                    {it}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="mt-10 flex flex-wrap justify-center gap-3">
          <button onClick={() => onNavigate("planes")} className="btn-primary">
            Ver planes →
          </button>
          <button onClick={() => onNavigate("herramientas")} className="btn-secondary">
            Ver herramientas IA
          </button>
        </div>
      </div>
    </div>
  )
}

/* ========== PLANES ========== */
type Plan = {
  id: string
  name: string
  monthly: number
  annual: number
  tagline: string
  features: string[]
  highlight?: boolean
  cta: string
}

const PLANS: Plan[] = [
  {
    id: "starter",
    name: "Starter",
    monthly: 599,
    annual: 479,
    tagline: "Perfecto para emprendedores que inician",
    features: [
      "Tienda online básica (hasta 20 productos)",
      "4 clips de video al mes con Opus Clip",
      "Configuración inicial en ClickUp",
      "Soporte por correo",
      "1 revisión mensual de estrategia",
    ],
    cta: "Comenzar gratis →",
  },
  {
    id: "pro",
    name: "Pro",
    monthly: 1299,
    annual: 1039,
    tagline: "El favorito de nuestros clientes",
    features: [
      "Tienda online completa (productos ilimitados)",
      "15 clips de video al mes con Opus Clip",
      "Edición de podcast con Autopod (2/mes)",
      "ClickUp personalizado para tu empresa",
      "Automatización de 3 flujos de trabajo",
      "Soporte prioritario por WhatsApp",
      "Reportes mensuales de desempeño",
    ],
    highlight: true,
    cta: "Obtener Pro →",
  },
  {
    id: "business",
    name: "Business",
    monthly: 2499,
    annual: 1999,
    tagline: "Para PYMES con grandes metas",
    features: [
      "Todo lo del plan Pro incluido",
      "Clips ilimitados con Opus Clip",
      "Podcast completo mensual con Autopod",
      "Tiendas en múltiples plataformas",
      "Automatizaciones empresariales ilimitadas",
      "Gestor de cuenta dedicado",
      "Capacitación en herramientas IA",
      "Acceso anticipado a nuevas funciones",
    ],
    cta: "Contactar equipo →",
  },
]

function PlanesSection({ onSelectPlan }: { onSelectPlan: (p: Plan) => void }) {
  const [billing, setBilling] = useState<"monthly" | "annual">("monthly")

  return (
    <div className="relative pt-[110px] pb-20">
      <div className="mx-auto max-w-7xl px-5 md:px-8">
        <div className="mx-auto max-w-3xl text-center">
          <span className="section-tag reveal">Precios accesibles</span>
          <h2
            className="reveal reveal-d1 mt-4 font-sans font-bold leading-[1.1] text-balance"
            style={{ fontSize: "clamp(2rem, 4.5vw, 3rem)", color: "var(--blue-deep)" }}
          >
            Elige el plan que se adapta a ti
          </h2>
          <p
            className="reveal reveal-d2 mt-5 leading-relaxed text-pretty"
            style={{ color: "var(--text-mid)" }}
          >
            Sin comisiones ocultas, sin contratos forzosos. Comienza con el plan que necesitas y escala
            cuando lo decidas.
          </p>
        </div>

        {/* Toggle */}
        <div className="reveal reveal-d3 mt-8 flex justify-center">
          <div
            className="inline-flex rounded-full p-1"
            style={{
              background: "rgba(255,255,255,0.7)",
              border: "1px solid rgba(168,212,240,0.5)",
              backdropFilter: "blur(12px)",
            }}
          >
            <button
              onClick={() => setBilling("monthly")}
              className="rounded-full px-5 py-2 text-[0.9rem] font-semibold transition"
              style={{
                background:
                  billing === "monthly" ? "linear-gradient(135deg, #2563a8, #4a9eda)" : "transparent",
                color: billing === "monthly" ? "#fff" : "var(--text-mid)",
              }}
            >
              Mensual
            </button>
            <button
              onClick={() => setBilling("annual")}
              className="rounded-full px-5 py-2 text-[0.9rem] font-semibold transition flex items-center gap-1.5"
              style={{
                background:
                  billing === "annual" ? "linear-gradient(135deg, #2563a8, #4a9eda)" : "transparent",
                color: billing === "annual" ? "#fff" : "var(--text-mid)",
              }}
            >
              Anual
              <span
                className="rounded-full px-1.5 py-0.5 text-[0.65rem] font-bold"
                style={{
                  background: billing === "annual" ? "rgba(255,255,255,0.25)" : "var(--blue-light)",
                  color: billing === "annual" ? "#fff" : "var(--blue-mid)",
                }}
              >
                −20%
              </span>
            </button>
          </div>
        </div>

        <div className="mt-10 grid gap-6 md:grid-cols-3">
          {PLANS.map((p, i) => {
            const price = billing === "monthly" ? p.monthly : p.annual
            const isHi = p.highlight
            return (
              <div
                key={p.id}
                className={`reveal reveal-d${i + 1} relative p-7 rounded-[18px] flex flex-col ${
                  isHi ? "" : "glass-card"
                }`}
                style={
                  isHi
                    ? {
                        background: "linear-gradient(160deg, #2563a8, #4a9eda)",
                        boxShadow: "0 24px 70px rgba(37,99,168,0.35)",
                        color: "#fff",
                        transform: "translateY(-4px)",
                      }
                    : undefined
                }
              >
                {isHi && (
                  <span
                    className="absolute -top-3 left-1/2 -translate-x-1/2 rounded-full px-3 py-1 text-[0.72rem] font-semibold"
                    style={{
                      background: "#fff",
                      color: "var(--blue-mid)",
                      boxShadow: "0 6px 18px rgba(0,0,0,0.12)",
                    }}
                  >
                    ⭐ Popular
                  </span>
                )}
                <h3
                  className="font-sans font-semibold"
                  style={{
                    color: isHi ? "#fff" : "var(--blue-deep)",
                    fontSize: "1.4rem",
                  }}
                >
                  {p.name}
                </h3>
                <p
                  className="mt-1 text-[0.88rem]"
                  style={{ color: isHi ? "rgba(255,255,255,0.85)" : "var(--text-soft)" }}
                >
                  {p.tagline}
                </p>

                <div className="mt-5 flex items-baseline gap-1.5">
                  <span
                    className="font-sans font-bold"
                    style={{
                      fontSize: "2.4rem",
                      color: isHi ? "#fff" : "var(--blue-deep)",
                      lineHeight: 1,
                    }}
                  >
                    ${price.toLocaleString("es-MX")}
                  </span>
                  <span
                    className="text-[0.85rem]"
                    style={{ color: isHi ? "rgba(255,255,255,0.8)" : "var(--text-soft)" }}
                  >
                    MXN/mes
                  </span>
                </div>

                <ul className="mt-6 space-y-3 flex-1">
                  {p.features.map((f) => (
                    <li
                      key={f}
                      className="flex items-start gap-2 text-[0.9rem] leading-relaxed"
                      style={{ color: isHi ? "rgba(255,255,255,0.92)" : "var(--text-mid)" }}
                    >
                      <svg width="18" height="18" viewBox="0 0 24 24" fill="none" className="mt-0.5 shrink-0">
                        <circle cx="12" cy="12" r="10" fill={isHi ? "rgba(255,255,255,0.2)" : "#dcfce7"} />
                        <path
                          d="M8 12l3 3 5-6"
                          stroke={isHi ? "#fff" : "#16a34a"}
                          strokeWidth="2"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                        />
                      </svg>
                      {f}
                    </li>
                  ))}
                </ul>

                <button
                  onClick={() => onSelectPlan(p)}
                  className="mt-7 rounded-full px-5 py-3 text-[0.92rem] font-semibold transition"
                  style={
                    isHi
                      ? {
                          background: "#fff",
                          color: "var(--blue-mid)",
                          boxShadow: "0 8px 24px rgba(0,0,0,0.18)",
                        }
                      : {
                          background: "transparent",
                          border: "1.5px solid var(--blue-pastel)",
                          color: "var(--blue-mid)",
                        }
                  }
                >
                  {p.cta}
                </button>
              </div>
            )
          })}
        </div>

        <p
          className="mt-8 text-center text-[0.85rem]"
          style={{ color: "var(--text-soft)" }}
        >
          Todos los planes incluyen onboarding guiado. Precios en MXN. Para cotizaciones personalizadas
          contáctanos.
        </p>
      </div>
    </div>
  )
}

/* ========== Footer ========== */
function Footer({ onNavigate }: { onNavigate: (p: PageId) => void }) {
  return (
    <footer className="site-footer relative mt-10">
      <div className="mx-auto grid max-w-7xl gap-10 px-5 py-14 md:grid-cols-4 md:px-8">
        <div>
          <div className="flex items-center gap-2.5">
            <span
              className="flex h-9 w-9 items-center justify-center rounded-[10px] font-sans font-bold text-white"
              style={{ background: "linear-gradient(135deg, #2563a8, #4a9eda)" }}
            >
              N
            </span>
            <span
              className="font-sans font-semibold text-white"
              style={{ letterSpacing: "1.5px" }}
            >
              NEXORA
            </span>
          </div>
          <p className="mt-4 text-[0.88rem] leading-relaxed" style={{ color: "rgba(255,255,255,0.7)" }}>
            Plataforma integral de crecimiento digital que combina e-commerce, marketing inteligente y
            automatización para emprendedores y PYMES.
          </p>
        </div>
        <div>
          <h4>Servicios</h4>
          <ul className="space-y-2">
            <li><button onClick={() => onNavigate("servicios")}>Comercio Digital</button></li>
            <li><button onClick={() => onNavigate("servicios")}>Marketing Inteligente</button></li>
            <li><button onClick={() => onNavigate("servicios")}>Automatización</button></li>
          </ul>
        </div>
        <div>
          <h4>Herramientas</h4>
          <ul className="space-y-2">
            <li><button onClick={() => onNavigate("herramientas")}>Build Your Store</button></li>
            <li><button onClick={() => onNavigate("herramientas")}>Autopod</button></li>
            <li><button onClick={() => onNavigate("herramientas")}>Opus Clip</button></li>
            <li><button onClick={() => onNavigate("herramientas")}>ClickUp</button></li>
          </ul>
        </div>
        <div>
          <h4>Empresa</h4>
          <ul className="space-y-2">
            <li><button onClick={() => onNavigate("nosotros")}>Nosotros</button></li>
            <li><button onClick={() => onNavigate("planes")}>Planes</button></li>
            <li><button onClick={() => onNavigate("inicio")}>Inicio</button></li>
          </ul>
        </div>
      </div>
      <div
        className="border-t"
        style={{ borderColor: "rgba(255,255,255,0.1)" }}
      >
        <div className="mx-auto flex max-w-7xl flex-col items-center justify-between gap-2 px-5 py-5 text-[0.82rem] md:flex-row md:px-8">
          <span style={{ color: "rgba(255,255,255,0.7)" }}>© 2026 NEXORA</span>
          <span style={{ color: "rgba(255,255,255,0.4)" }}>Toluca, México · Proyecto Integrador</span>
        </div>
      </div>
    </footer>
  )
}

/* ========== Modal ========== */
function PlanModal({
  plan,
  billing,
  onClose,
}: {
  plan: Plan
  billing: "monthly" | "annual"
  onClose: () => void
}) {
  const [step, setStep] = useState<1 | 2>(1)
  const [form, setForm] = useState({ name: "", email: "", business: "", phone: "", message: "" })
  const [error, setError] = useState("")

  const submit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!form.name || !form.email || !form.business) {
      setError("Por favor completa los campos requeridos.")
      return
    }
    setError("")
    setStep(2)
    // Open mail client
    const subject = encodeURIComponent(`Solicitud plan ${plan.name} — NEXORA`)
    const body = encodeURIComponent(
      `Hola equipo NEXORA,\n\nMe interesa el plan ${plan.name}.\n\nNombre: ${form.name}\nCorreo: ${form.email}\nNegocio: ${form.business}\nTeléfono: ${form.phone}\n\nNecesidad: ${form.message}`
    )
    setTimeout(() => {
      window.location.href = `mailto:contacto@nexora.mx?subject=${subject}&body=${body}`
    }, 600)
  }

  const price = billing === "monthly" ? plan.monthly : plan.annual

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div
        className="glass-card relative w-full max-w-2xl overflow-hidden"
        style={{ background: "rgba(255,255,255,0.95)" }}
        onClick={(e) => e.stopPropagation()}
      >
        <button
          onClick={onClose}
          aria-label="Cerrar"
          className="absolute right-4 top-4 flex h-9 w-9 items-center justify-center rounded-full"
          style={{ background: "var(--blue-light)", color: "var(--blue-mid)" }}
        >
          ✕
        </button>

        <div className="p-7 md:p-9">
          <span className="section-tag">Plan {plan.name}</span>
          <h3 className="mt-3 font-sans text-[1.6rem] font-bold" style={{ color: "var(--blue-deep)" }}>
            Comienza con NEXORA
          </h3>
          <p className="mt-1 text-[0.92rem]" style={{ color: "var(--text-soft)" }}>
            {plan.tagline}
          </p>

          {/* Plan summary */}
          <div
            className="mt-5 rounded-[12px] p-4"
            style={{ background: "var(--blue-frost)", border: "1px solid rgba(168,212,240,0.5)" }}
          >
            <div className="flex items-baseline justify-between">
              <span className="font-sans font-semibold" style={{ color: "var(--blue-deep)" }}>
                {plan.name}
              </span>
              <span className="font-sans font-bold" style={{ color: "var(--blue-mid)", fontSize: "1.3rem" }}>
                ${price.toLocaleString("es-MX")} <span className="text-[0.75rem] font-normal">MXN/mes</span>
              </span>
            </div>
            <ul className="mt-3 space-y-1 text-[0.85rem]" style={{ color: "var(--text-mid)" }}>
              {plan.features.slice(0, 4).map((f) => (
                <li key={f}>• {f}</li>
              ))}
            </ul>
          </div>

          {/* Steps indicator */}
          <div className="mt-6 flex items-center gap-3 text-[0.8rem]">
            <span
              className="flex items-center gap-2 rounded-full px-3 py-1.5 font-semibold"
              style={{
                background: step === 1 ? "linear-gradient(135deg,#2563a8,#4a9eda)" : "var(--blue-light)",
                color: step === 1 ? "#fff" : "var(--blue-mid)",
              }}
            >
              1 → Registro
            </span>
            <span style={{ color: "var(--text-soft)" }}>—</span>
            <span
              className="flex items-center gap-2 rounded-full px-3 py-1.5 font-semibold"
              style={{
                background: step === 2 ? "linear-gradient(135deg,#2563a8,#4a9eda)" : "var(--blue-light)",
                color: step === 2 ? "#fff" : "var(--blue-mid)",
              }}
            >
              2 → Confirmación
            </span>
          </div>

          {step === 1 ? (
            <form onSubmit={submit} className="mt-6 grid gap-4 md:grid-cols-2">
              <Field label="Nombre completo *" value={form.name} onChange={(v) => setForm({ ...form, name: v })} />
              <Field
                label="Correo electrónico *"
                type="email"
                value={form.email}
                onChange={(v) => setForm({ ...form, email: v })}
              />
              <Field
                label="Nombre de tu negocio *"
                value={form.business}
                onChange={(v) => setForm({ ...form, business: v })}
              />
              <Field
                label="Teléfono (opcional)"
                type="tel"
                value={form.phone}
                onChange={(v) => setForm({ ...form, phone: v })}
              />
              <div className="md:col-span-2">
                <label className="block text-[0.85rem] font-medium" style={{ color: "var(--text-mid)" }}>
                  ¿Qué necesitas mejorar en tu negocio?
                </label>
                <textarea
                  value={form.message}
                  onChange={(e) => setForm({ ...form, message: e.target.value })}
                  rows={3}
                  className="mt-1.5 w-full rounded-[12px] px-4 py-2.5 text-[0.92rem] outline-none"
                  style={{
                    background: "rgba(255,255,255,0.85)",
                    border: "1px solid rgba(168,212,240,0.6)",
                    color: "var(--text-dark)",
                  }}
                />
              </div>
              {error && (
                <div className="md:col-span-2 text-[0.85rem]" style={{ color: "#dc2626" }}>
                  {error}
                </div>
              )}
              <div className="md:col-span-2 flex flex-wrap justify-end gap-3 mt-2">
                <button type="button" onClick={onClose} className="btn-secondary">
                  Cancelar
                </button>
                <button type="submit" className="btn-primary">
                  Enviar solicitud →
                </button>
              </div>
            </form>
          ) : (
            <div className="mt-6 text-center">
              <div
                className="mx-auto flex h-16 w-16 items-center justify-center rounded-full"
                style={{ background: "linear-gradient(135deg,#22c55e,#4a9eda)", color: "#fff" }}
              >
                <svg width="30" height="30" viewBox="0 0 24 24" fill="none">
                  <path
                    d="M5 12l5 5L20 7"
                    stroke="currentColor"
                    strokeWidth="2.5"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                </svg>
              </div>
              <h4 className="mt-4 font-sans text-[1.3rem] font-bold" style={{ color: "var(--blue-deep)" }}>
                ¡Solicitud enviada!
              </h4>
              <p className="mt-2 text-[0.95rem] leading-relaxed" style={{ color: "var(--text-mid)" }}>
                Tu solicitud para el {plan.name} ha sido registrada. El equipo NEXORA te contactará en
                menos de 24 horas al correo {form.email}.
              </p>
              <p className="mt-3 text-[0.82rem]" style={{ color: "var(--text-soft)" }}>
                📧 Se abrirá tu cliente de correo para enviar la confirmación directamente al equipo.
              </p>
              <button onClick={onClose} className="btn-primary mt-5">
                Cerrar
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

function Field({
  label,
  value,
  onChange,
  type = "text",
}: {
  label: string
  value: string
  onChange: (v: string) => void
  type?: string
}) {
  return (
    <div>
      <label className="block text-[0.85rem] font-medium" style={{ color: "var(--text-mid)" }}>
        {label}
      </label>
      <input
        type={type}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="mt-1.5 w-full rounded-[12px] px-4 py-2.5 text-[0.92rem] outline-none transition"
        style={{
          background: "rgba(255,255,255,0.85)",
          border: "1px solid rgba(168,212,240,0.6)",
          color: "var(--text-dark)",
        }}
      />
    </div>
  )
}

/* ========== ROOT ========== */
export default function Page() {
  const [page, setPage] = useState<PageId>("inicio")
  const [transitioning, setTransitioning] = useState(false)
  const [transitionPhase, setTransitionPhase] = useState<"in" | "out" | null>(null)
  const [modalPlan, setModalPlan] = useState<Plan | null>(null)
  const [billing] = useState<"monthly" | "annual">("monthly")
  const overlayRef = useRef<HTMLDivElement>(null)

  const navigate = (next: PageId) => {
    if (next === page || transitioning) return
    setTransitioning(true)
    setTransitionPhase("in")
    setTimeout(() => {
      setPage(next)
      window.scrollTo({ top: 0, behavior: "instant" })
      setTransitionPhase("out")
      setTimeout(() => {
        setTransitioning(false)
        setTransitionPhase(null)
      }, 450)
    }, 450)
  }

  useReveal()
  // re-run reveal when page changes
  useEffect(() => {
    const els = document.querySelectorAll(".reveal")
    els.forEach((el) => el.classList.remove("visible"))
    const io = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) => {
          if (e.isIntersecting) {
            e.target.classList.add("visible")
            io.unobserve(e.target)
          }
        })
      },
      { threshold: 0.12 }
    )
    els.forEach((el) => io.observe(el))
    return () => io.disconnect()
  }, [page])

  return (
    <>
      {/* Background blobs */}
      <div className="blob blob-1" aria-hidden />
      <div className="blob blob-2" aria-hidden />
      <div className="blob blob-3" aria-hidden />

      <Navbar current={page} onNavigate={navigate} />

      <main className="relative z-10">
        {page === "inicio" && <HeroSection onNavigate={navigate} />}
        {page === "nosotros" && <NosotrosSection onNavigate={navigate} />}
        {page === "herramientas" && <HerramientasSection />}
        {page === "servicios" && <ServiciosSection onNavigate={navigate} />}
        {page === "planes" && <PlanesSection onSelectPlan={(p) => setModalPlan(p)} />}
      </main>

      <Footer onNavigate={navigate} />

      {transitionPhase && (
        <div
          ref={overlayRef}
          className={`page-transition ${transitionPhase === "in" ? "slide-in" : "slide-out"}`}
        />
      )}

      {modalPlan && (
        <PlanModal plan={modalPlan} billing={billing} onClose={() => setModalPlan(null)} />
      )}
    </>
  )
}
